document.write("Olá a todos!...");
